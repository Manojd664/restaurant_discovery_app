from flask import Flask
from app import app

app = Flask(__name__)


@app.route('/')
@app.route('/restaurants')
def showRestaurants():
    pass


@app.route('/restaurants/menu')
def showRestaurantsForMenu():
    pass


@app.route('/customer/register')
def customerRegister():
    pass


@app.route('/customer/login')
def customerLogin():
    pass


@app.route('/restaurant/register')
def restaurantRegister():
    pass


@app.route('/restaurant/login')
def restaurantLogin():
    pass


@app.route('/restaurant/<int:restaurant_id>/delete')
def deleteRestaurant(restaurant_id):
    pass


@app.route('/restaurant/<int:restaurant_id>/edit/')
def restaurantUpdate(restaurant_id):
    pass


@app.route('/restaurant/<int:restaurant_id>/rate/')
def rateRestaurant(restaurant_id):
    pass
