customer_file_name = "/python/com/data/customer.csv"
restaurant_file_name = "/python/com/data/restaurant.csv"
db_name=""
