from python.com.tide.db_model import DBOperations


class Admin:
    def __init__(self):
        self.db_model_obj = DBOperations()

    def login(self, user_name, password):
        result = self.db_model_obj.get_with_id(None, "restaurant", user_name)
        if result is not None and result == password:
            return True
        else:
            return False

    def register(self, restaurant_info_dict):
        status = self.db_model_obj.insert("restaurant", restaurant_info_dict)
        return status

    def un_register(self, restaurant_id):
        self.db_model_obj.delete("restaurant", restaurant_id)

    def update(self, restaurant_id, update_info_dict):
        self.db_model_obj.update("restaurant", restaurant_id, update_info_dict)
