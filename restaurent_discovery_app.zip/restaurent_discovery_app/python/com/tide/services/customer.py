from python.com.tide.models.db_model import DBOperations


class Customer:
    def __init__(self):
        self.db_model_obj = DBOperations()

    def list_restaurant_with_menu(self, menu_list):
        df = self.db_model_obj.get_all(None, "restaurant")

    def login(self, user_name, password):
        result = self.db_model_obj.get_with_id(None, "customer", user_name)

    def sign_up(self, customer_info):
        values_dict={}
        self.db_model_obj.insert(None, "customer", customer_info,values_dict)

    def rate_restaurant(self, restaurant_id, customer_id, rating):
        values_dict = {"customer_id": customer_id, "restaurant_id": restaurant_id, "rating": rating}
        self.db_model_obj.insert(None, "feedback", values_dict)
