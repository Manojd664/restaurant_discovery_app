import pandas as pd


class DBOperations:
    def __init__(self):
        self.user_nanme = ""
        self.password = ""

    def get_all(self, db_name, table_name):
        df = pd.read_csv(table_name)
        return df

    def get_with_id(self, db_name, table_name, id):
        df = pd.read_csv(table_name)

    def insert(self, db_name, table_name, values_dict):
        status = True
        try:
            pass
        except:
            status = False
        return status

    def update(self, db_name, table_name, update_dict):
        pass

    def delete(self, db_name, table_name, id):
        pass
