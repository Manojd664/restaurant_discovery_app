customer_file_name = "/Users/manojkumardhakad/Desktop/restaurent_discovery_app/python/com/data/customer.csv"
restaurant_file_name = "/Users/manojkumardhakad/Desktop/restaurent_discovery_app/python/com/data/restaurant.csv"
db_name=""
