# restaurant_discovery_app
The purpose of this app is to serve the aim of restaurant as per requiremnts

Modules:

1. test:it contains unit test cases of each module , developed using pytest
2. python: Contains models like model, view, controller/services
2.1. Configs: It contains all the configs files which is required to externalise configuration like secret keys, user names, passwords etc
2.2. model: This contains data
2.3. sevices: it contins  all the services.